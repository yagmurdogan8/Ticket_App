﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MobileProgrammingA2_3
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Page2 : ContentPage
    {
        public static String userIDDet, userNameDet, HESDet, ticketID;
        public Page2()
        {
            
            InitializeComponent();

            IDDet.Text += " : ";
            IDDet.Text += userIDDet; 
            
            NameDet.Text += " : ";
            NameDet.Text += userNameDet;

            hesDet.Text += " : ";
            hesDet.Text += HESDet;

            tcktID.Text += " : ";
            tcktID.Text += ticketID;
        }
    }
}