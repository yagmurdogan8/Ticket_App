﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.ComponentModel;
using System.Text.RegularExpressions;

namespace MobileProgrammingA2_3
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Page1 : ContentPage
    {
        
        public Page1()
        {
            InitializeComponent();
        }
        public async void Button_Clicked2(object sender, EventArgs e)
        {
            String userIDRegister = userIDReg.Text;
            String userNameRegister = userNameReg.Text;
            String HESRegister = HESReg.Text;
            Boolean isExist = false;
            //ImageSource img;
            FileImageSource img;

            String pattern = @"^([A-Z]{2}[0-9]{2}\-[0-9]{4}\-[0-9]{4}\-[0-9]{2})$";
            Regex rg = new Regex(pattern);

            if (rg.IsMatch(HESRegister))
            {
                img = "checked.png";

                for (int i = 0; i < App.list.Count(); i++)
                {
                    if (App.list[i][0].Equals(userIDRegister) && App.list[i][1].Equals(HESRegister))
                    {
                        isExist = true;
                        tckEx.IsVisible = true;
                        System.Threading.Thread.Sleep(1000);
                        await Navigation.PushAsync(new MainPage(), true);
                        tckEx.IsVisible = false;
                    }
                }

                if (isExist == false)
                {
                    String TicketID = GenerateNumber();

                    App.list.Add(new List<string> { userIDRegister, HESRegister, userNameRegister, TicketID });

                    Page2.userIDDet = userIDRegister;
                    Page2.HESDet = HESRegister;
                    Page2.userNameDet = userNameRegister;
                    Page2.ticketID = TicketID;

                    tckCre.IsVisible = true;
                    System.Threading.Thread.Sleep(1000);

                    await Navigation.PushAsync(new Page2(), true);
                    tckCre.IsVisible = false;
                }
            }             
                else
                    img = "cancel.png";

        }
        public static string GenerateNumber()
        {

            Random R = new Random();

            String number = ((long)R.Next(0, 100000) * (long)R.Next(0, 100000)).ToString().PadLeft(10, '0');

            Boolean isExist2 = false;

            for (int i = 0; i < App.list.Count(); i++)
            {
                if (App.list[i][3].Equals(number))
                {
                    isExist2 = true;

                }
            }
            if (isExist2)
            {
                GenerateNumber();
            }

            return number;
        }
    }
}